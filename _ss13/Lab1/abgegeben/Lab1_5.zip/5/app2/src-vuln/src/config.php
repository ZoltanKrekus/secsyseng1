<?php

	/* parameters for mysql database connection */
	define("SQL_HOST", "localhost");		/* hostname or ip where to find the mysql database server */
	define("SQL_USER", "isec");			/* username to connect to the database server */
	define("SQL_PASS", "isec");			/* password to connect to the database server */
	define("SQL_DB", "isec");			/* database where to find the tables */
	

?>
